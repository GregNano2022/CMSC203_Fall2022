     
public class Property 
{
private static  String newProperty;
private static String newPropertyName;
private  String newPropertyCity;
private  double newPropertyRent;
private  String newPropertyOwner;
private  int newPropertyXDimensions;
private  int newPropertyYDimensions;
private  int newPropertyWidth;
private static int newPropertydepth;
private String City;
private String Owner;
private  Plot plot;
private  String PropertyName;
private double RentAmount;
private String propertyName;
private  String city;
private  String owner;
private String rentAmount;


public Property()
{
	newProperty ="";
}
public Property(String propertyName, String city, double rentAmount, String owner)
{
	newPropertyName = propertyName;
	newPropertyCity = city;
	newPropertyRent = rentAmount;
	newPropertyOwner = owner;
}
public Property(String propertyName, String city, double rentAmount, String owner, int x, int y, int width, int depth)
{
	newPropertyName = propertyName;
	newPropertyCity = city;
	newPropertyRent = rentAmount;
	newPropertyOwner = owner;
	newPropertyXDimensions = x;
	newPropertyYDimensions = y;
	newPropertyWidth = width;
	newPropertydepth = depth;
}
/**The copy constructor initializes the object as a copy of another property object.
 * @param otherProperty
 */
public Property(Property otherProperty)
{

	newPropertyName = otherProperty.newPropertyName;
	newPropertyCity = otherProperty.newPropertyCity;
	newPropertyRent = otherProperty.newPropertyRent;
	newPropertyOwner = otherProperty.newPropertyOwner;
	newPropertyXDimensions = otherProperty.newPropertyXDimensions;
	newPropertyYDimensions = otherProperty.newPropertyYDimensions;
	newPropertyWidth = otherProperty.newPropertyWidth;
	newPropertydepth = Property.newPropertydepth;

}
public String getCity()
{
	return City;
}
public String getOwner()
{
	return Owner;
}
public Plot getPlot()
{
	return new Plot(plot);
}
public String getPropertyName()
{
	return PropertyName;
}
public double getRentAmount()
{
	return RentAmount;
}
public String toString()
{
	String str = "Property Name: " + propertyName +
		     "\nCity: " + city +
		      "\nProperty Owner: " + owner +
		       "\nRent Amount: " + rentAmount ;
return str;
}
}