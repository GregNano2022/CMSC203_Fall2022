import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ManagementCompanyTestStudent {
Property GeorgeRealty;
static ManagementCompany GeorgeRealtyManagement;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		GeorgeRealtyManagement= new ManagementCompany("George", "789643215",7);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		GeorgeRealtyManagement=null;
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	public void testAddProperty() {
		GeorgeRealty = new Property ("MCCollege", "John", 12345, "James Douglas",6,7,3,3);		 
		assertEquals(GeorgeRealtyManagement.addProperty(GeorgeRealty),0,0);	//property has been successfully added to index 0
	}
	
	@Test
	public void testGetPropertiesCount() {
		GeorgeRealty = new Property ("Texas", "James", 2733, "Mary Stewart",8,3,2,2);		 
		assertEquals(GeorgeRealtyManagement.addProperty(GeorgeRealty),0,0);	
		assertEquals(GeorgeRealtyManagement.getPropertiesCount(), 1);
	}

	@Test
	public void testToString() {
		assertEquals("10,20,7,7", GeorgeRealtyManagement.toString());
	}
}