import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PropertyTestStudent {
static Property propertySeven;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		propertySeven = new Property("TakomaParkHeights", "Takoma Park", 1800.00, "City of Takoma Park");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
		propertySeven=null;
	}

	@Test
	void test() {
		assertEquals("TakomaParkHeights", propertySeven.getPropertyName());;
	}
	@Test
	void testGetRentAmount() {
		assertEquals(1800.00, propertySeven.getRentAmount());
	}

	@Test
	void testGetPlot() {
		assertEquals(0, propertySeven.getPlot().getX());
		assertEquals(0, propertySeven.getPlot().getY());
		assertEquals(1, propertySeven.getPlot().getWidth());
		assertEquals(1, propertySeven.getPlot().getDepth());
}
	@Test
	void testToString() {
		assertEquals("TakomaParkHeights , Takoma Park, 1800.00, City of Takoma Park",propertySeven.toString());	
	}
}