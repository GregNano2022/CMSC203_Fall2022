
public class Plot
{
private static int Width;
private static int depth;
private static int plot1;
private static int PlotXCoordinate ;
private static int PlotYCoordinate;
private static int PlotDepth;
private static int X;
private static int Y;
private static int Depth;
private  static int plot;




Plot()
{
	Width =1;
	depth=1;
}
public Plot(int x, int y, int width, int depth)
{
	PlotXCoordinate=x;
	PlotYCoordinate = y;
	Width= width;
	PlotDepth = depth;   

}


public Plot(Plot otherPlot)
{
   PlotXCoordinate = otherPlot.PlotXCoordinate;
	PlotYCoordinate = otherPlot.PlotYCoordinate;
	Width =otherPlot.Width ;
	PlotDepth =otherPlot.PlotDepth;   
	
}

public boolean encompasses (Plot plot)
{
	boolean encompasses =true;

	if (this.plot>=X && this.plot>=Y && this.plot>=depth)
	{
	encompasses= false;
	}
	return encompasses;
	
}
public int getDepth()
{
	return depth;
	
}
public int getWidth()
{
	return Width;
}
public int getX()
{
	return X;
}
public int getY()
{
	return Y;
}
public boolean overlaps(Plot plot)
{
	boolean overlaps =true;

	if (this.plot>=PlotXCoordinate && this.plot>=PlotYCoordinate && this.plot>=PlotDepth)
	{
	overlaps= false;
	}
	return overlaps;
	
}
public void setDepth(int depth)
{
	Depth = depth;
}
public void setWidth(int width)
{
	Width = width;
}
public void setX(int x)
{
	X = x;
}
public void setY(int y)
{
	Y = y;
}
public String toString()
{
	String str = "X: " + X +
		     "\nY: " + Y +
		      "\nWidth: " + Width +
		       "\nDepth: " + depth ;
return str;
	        
}
}