import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PlotTestStudent {
private static Plot plot3;
private static Plot plot4;
private static Plot plot5;
private static Plot plot6;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		plot3 = new Plot(4, 5, 6, 7);
		plot4 = new Plot(7, 9, 4, 8);
		plot5 = new Plot(3, 8, 6, 7);
		plot6 = new Plot(2, 4, 9, 8);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
		plot3 = plot4 = null;
		plot5 = plot6 =null;
	}

	@Test
	void test() {
		assertTrue(plot3.overlaps(plot4)); // plot5 is entirely inside plot1;
		assertTrue(plot4.overlaps(plot5)); // plot5 is entirely inside plot1;
	}

}
