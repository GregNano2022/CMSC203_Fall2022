
/*
 * Class: CMSC203 
 * Instructor:Professor Gary Thai
 * Description: 
 * A property management company manages individual properties they will build to rent,
 *  and charges them a management fee as the percentages of the monthly rental amount. 
 *  The properties cannot overlap each other, and each property must be within the
 *   limits of the management company’s plot.  
 *   This is an application that lets the user create a management company and
 *    add the properties managed by the company to its list. 
 * The maximum number of properties handled by the company is 5.  
 * We are creating a Plot.java, Property.java, ManagementCompany.java and 
 * accompanying test.java files .We are provided with a GUI that should allow an interface
 * portal that will enable adding and removing properties
 * 
 * Due: 10/29/2022
 * Platform/compiler:
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: George Ngatha
*/


import java.util.ArrayList;

import javafx.scene.image.ImageView;

public class ManagementCompany
{ 
	//Declaring Fields and Variables
	public static final int MAX_PROPERTY = 5;
	public static final int MGMT_DEPTH = 10;
	public static final int MGMT_WIDTH = 10;
	private int PlotWidth;
	private int PlotDepth;
	private String ManagementCompanyName;
	private double managementFee;
	private String taxId;
	private int PlotLength;
	private String PropertyName;
	private String PropertyCity;
	private double PropertyRent;
	private String PropertyOwner;
	private int numberOfProperties;
	private String Name;
	private String rentAmount;
	private int PropertiesCount;
	private int x;
	private int depth;
	private int y;
	private String city;
	private String rent;
	private String owner;
	private Plot plot ;
	public  int[] properties ;
	private  Property highestRentProperty;
	private  Property[] Properties1;
	private  Plot Plot1;
	private int PropertyAdded;
	private Object property;
	
	public ManagementCompany()
{
	Name = "";
	PlotWidth = x;
	PlotLength= y;
	PlotDepth=depth;
}
public ManagementCompany(String name, String taxID, double mgmFee)
{
	Name = "";
	taxId = taxID;
	PlotWidth = x;
	PlotLength= y;
	PlotDepth=depth;
	managementFee = mgmFee;
}
public ManagementCompany(String name, String taxID, double mgmFee, int x, int y, int width, int depth)
{
	ManagementCompanyName = name;
	taxId = taxID;
	managementFee = mgmFee;
	PlotLength = x;
	PlotWidth = y;
	PlotDepth = depth;
}
public ManagementCompany(ManagementCompany otherCompany)
{
	ManagementCompanyName = otherCompany.ManagementCompanyName;
	taxId = otherCompany.taxId;
	managementFee = otherCompany.managementFee;
	PlotLength = otherCompany.PlotLength;
	PlotWidth = otherCompany.PlotWidth;
	PlotDepth = otherCompany.PlotDepth;
}
public int addProperty(String name, String city, double rent, String owner)
{
	int rtnValue = addProperty(name, city, rent, owner);
	switch (rtnValue) {
	case -1: {
		PropertiesArrayFull(property);
		break;
	}
	case -2: {
		PropertyIsNull(properties);
		break;
	}
	case -3: {
		alertDoesNotEncompass(properties);
		break;
	}
	case -4: {
		alertOverlap(properties);
		break;
	}
	default: // the case where property is valid and created - now display icon
		for(int i = 0; i<properties.length; i++)
		{
				
			ArrayList<Object> addProperty = new ArrayList<Object>();
			addProperty.add(name);
			addProperty.add(city);
			addProperty.add(rent);
			addProperty.add(owner);
			properties[i]=PropertyAdded;
		}
	}
			return PropertyAdded ;

}

private void alertOverlap(int[] properties2) {
	// TODO Auto-generated method stub
	
}
private void alertDoesNotEncompass(int[] properties2) {
	// TODO Auto-generated method stub
	
}
private void PropertyIsNull(int[] properties2) {
	// TODO Auto-generated method stub
	
}
private void PropertiesArrayFull(Object property2) {
	// TODO Auto-generated method stub
	
}
public int addProperty(String name, String city, double rent,  String owner, int x, int y, int width, int depth)
{
	int rtnValue = addProperty(name, city, rent, owner);
	switch (rtnValue) {
	case -1: {
		PropertiesArrayFull(property);
		break;
	}
	case -2: {
		PropertyIsNull(properties);
		break;
	}
	case -3: {
		alertDoesNotEncompass(properties);
		break;
	}
	case -4: {
		alertOverlap(properties);
		break;
	}
	default: // the case where property is valid and created - now display icon
		for(int i = 0; i<properties.length ; i++)
		{
		ArrayList<Object> addProperty = new ArrayList<Object>();
		addProperty.add(this.Name);
		addProperty.add(this.city);
		addProperty.add(this.rent);
		addProperty.add(this.owner);
		addProperty.add(x);
		addProperty.add(y);
		addProperty.add(width);
		addProperty.add(depth);
		properties[i]=PropertyAdded;
		}
	return numberOfProperties ;
		}
	return rtnValue;
	}
			
public int addProperty(Property property)
{

	final int rtnValue = addProperty(property);
	switch (rtnValue) {
	case -1: {
		PropertiesArrayFull(property);
		break;
	}
	case -2: {
		PropertyIsNull(properties);
		break;
	}
	case -3: {
		alertDoesNotEncompass(properties);
		break;
	}
	case -4: {
		alertOverlap(properties);
		break;
	}
	default: // the case where property is valid 
	int[] properties = {MAX_PROPERTY};
		for(int i = 0; i<properties.length; i++)
		{
		ArrayList<Object> addProperty = new ArrayList<Object>();
		addProperty.add(PropertyName);
		addProperty.add(PropertyCity);
		addProperty.add(PropertyRent);
		addProperty.add(PropertyOwner);
		addProperty.add(PlotLength);
		addProperty.add(PlotWidth);
		addProperty.add(PlotDepth);
		properties[i]=PropertyAdded;
		
}
	}
	return PropertyAdded;
}
    

public void removeLastProperty()
{
	ArrayList<Object>properties= new ArrayList<Object>();
	properties.remove(properties.size()-1);
	
}
public boolean isPropertiesFull()
{
	boolean PropertiesFull = false;
	for (int i =0; i<properties.length; i++)
		if(properties[i]>5)
		{
			PropertiesFull = true;
		}
	return PropertiesFull;
}
public int getPropertiesCount()
{
	
	for (int i = 0; i<properties.length; i++)  
	{
		properties[i]=PropertiesCount;
	}
	return  PropertiesCount;
	
	
}
public double getTotalRent()
{
	int[] properties = {MAX_PROPERTY};
	double TotalRent=0;
	for (int i = 0; i<properties.length; i++)
	{
	TotalRent+=properties[i];
	}
	return TotalRent;
}
public  Property getHighestRentProperty()
{
	int[] properties = {MAX_PROPERTY};
   double HighestRentProperty = 0;
	for (int i= 0; i<properties.length; i++)
	{
		if (properties[i]>HighestRentProperty)
			HighestRentProperty=properties[i];
	}
	return new Property(highestRentProperty);
	

}
public boolean isManagementFeeValid()
{
	if (managementFee>0 && managementFee<100)
	{
	return true;
	}
	return false;
}
public String getName()
{
	return Name;
}
public String getTaxID()
{
	return taxId;
}
public Property[] getProperties()
{
	
	return new Property[MAX_PROPERTY];
}

public Plot getPlot()
{
	return  new Plot(plot);
}


public String toString()
{
	String str = "Property Management Name: " + Name +
		     "\nProperty Management Company TaxID: " + taxId +
		      "\nProperty Name: " + Name +
		       "\nrent Amount: " + rentAmount ;
return str;
}



}
