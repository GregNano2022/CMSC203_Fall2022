
public class Coffee extends Beverage
{
	
	private static final int Price_ExtraShot = 0;
	private static final int PRICE_ExtraSyrup = 0;
	//private String bevName;
	//private Size bevSize;
	private boolean ExtraShot;
	private boolean ExtraSyrup;
	private double PRICE_COFFEE;
	private int BasePrice;
	

	public Coffee(String bevName, Size size, boolean extraShot, boolean extraSyrup)
	{
		//bevName - beverage name
		//size - beverage size
		//extraShot - true if extra coffee shot added , false otherwise
		//extraSyrup - true if extra syrup is added , false otherwise
		//this.bevName=bevName;
		//bevSize=size;
		super(bevName, bevType, size);
		ExtraShot=extraShot  ;
		ExtraSyrup= extraSyrup;
		
	}
	//Indicates whether or not extra shot is added
	public boolean getExtraShot()
	{
		boolean status;
		if(ExtraShot=true)
		status = true;
		else
		status = false;
		return status;
	}
	//Indicates whether or not extra syrup is added
	public boolean getExtraSyrup()
	{
		boolean status;
		if(ExtraSyrup=true)
		  status=true;
		else
			status = false;
		return status;
	}
	//Calculates the price based on base price, size,
	//extra coffee shot and extra syrup
	public double calcPrice()
	{
		PRICE_COFFEE = BasePrice + SIZE_PRICE + Price_ExtraShot + PRICE_ExtraSyrup;
		return  PRICE_COFFEE;
		
	}
	//Represents a Coffee beverage in the following String format:
	//name,size, whether it contains extra shot, extra syrup and the price
	@Override
	public String toString()
	{
		String str;
		str = "\name: " + bevName +
				"\nSize: " + bevSize +
				"\nContains extra Shot? " + ExtraShot+
				"\nContains extraSyrup? "+ ExtraSyrup +
				"\n Price:"+ PRICE_COFFEE;
		return str;
	}
	//Checks if this Beverage equals to anotherBev
	@Override
	public boolean equals(Object anotherBev)
	{
		boolean status;
		 if(bevName==anotherBev && bevName==anotherBev && bevSize==anotherBev)
			 status = true;
		 else
			 status = false;
		return status;
	}
	
	
	
}
