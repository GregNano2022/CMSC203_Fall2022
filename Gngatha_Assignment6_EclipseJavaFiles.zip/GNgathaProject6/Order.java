
public abstract class Order extends Object implements OrderInterface, Comparable<Order>
{ 
	public static Order CurrentOrder;
	private String bevName;
	private Customer customer; //a customer object
	private Day OrderDay;
	private int OrderNumber;
	private int OrderTime;
	private Day orderDay;
	private Object SATURDAY;
	private Object SUNDAY;
	private Object dayOfTheWeek;
	private int TotalItems;
	private int itemNo;
	private double OrderTotal=0.0;
	private String customerAge;
	private String listOfBeverages;
	private Customer customerName;
	private Beverage BeverageName;
	private Size bevSize;
	private boolean ExtraShot;
	private boolean ExtraSyrup;
	private int numOfFruits;
	private boolean AddProtein;
	public abstract int random();
	
	public Order(int orderTime, Day orderDay, Customer cust)
	{
		OrderTime=orderTime;
		OrderDay= orderDay;
		customerName=cust;
	}
	//Automatically generate order number
	public int generateOrder()
	{
		return random();
	}
	
	public int getOrderNo()
	{
		return OrderNumber;
	}
	public int getOrderTime()
	{
		return OrderTime;
	}
	public Day getOrderDay()
	{
		return orderDay;
	}
	public Customer getCustomer()
	{
		return new Customer(customer);
	}
	public Day getDay()
	{
		return OrderDay;
	}
	public boolean isWeekend()
	{
		boolean status;
		if (dayOfTheWeek == SATURDAY || dayOfTheWeek == SUNDAY)
			status = true;
		else
			status = false;
		return status;
	}
	public Beverage getBeverage(int itemNo)
	{
		this.itemNo=itemNo;
		return BeverageName;
		
	}
	//returns the total number of beverages ordered within this order
	public int getTotalItems()
	{
		 return TotalItems;
	}
	//adds coffee order to this order
	public void addNewBeverage(String bevName, Size size, boolean extraShot, boolean extraSyrup)
	{
		        this.bevName=bevName;
				bevSize=size;
		        ExtraShot=extraShot;
		        ExtraSyrup=extraSyrup;
		
	}
	//Adds alcohol order to this order
	public void addNewBeverage(String bevName, Size size)
	{
		this.bevName = bevName;
		bevSize=size;
	}
	//Add Smoothie order to this order 
	public void addNewBeverage(String bevName, Size size, int numOfFruits, boolean addProtein)
	{
		this.bevName=bevName;
		bevSize=size;
        this.numOfFruits=numOfFruits;
        AddProtein=addProtein;
		
	}
	//Calculates and returns the total amount for this order
	public double calcOrderTotal()
	{
		
		//OrderTotal=5;
		return OrderTotal;
	}

	public int findNumOfBeveType(Type type)
	{
		return OrderNumber;  
	}
	//String representation of the order, Includes order number, time ,
	//day, customer name and age and the list of beverages
	@Override
	public String toString()
	{
		String str;
		str = "\nOrder Number: " + OrderNumber +
				"\nTime: " + OrderTime +
				"\nDay: " + dayOfTheWeek +
				"\nCustomer Name: " + customer +
				"\nAge: " + customerAge +
				"\nList of Beverages: " + listOfBeverages;
				return str;  	
	}

	public Order get(Order order) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
