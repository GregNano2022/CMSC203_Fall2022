
public class Day {

	public static final Day SUNDAY = null;
	public static Day MONDAY;

}
