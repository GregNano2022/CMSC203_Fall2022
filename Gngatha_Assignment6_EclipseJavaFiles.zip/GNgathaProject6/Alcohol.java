
public class Alcohol extends Beverage
{
	private String bevName;
	private Size bevSize;
	private boolean IsWeekend;
	private double PRICE_ALCOHOL;
	private static Type bevType;
	private double anotherBev;
/**
 * Constructor Alcohol Creates an Alcohol object using given values
 */
	public Alcohol(String bevName, Size size, boolean isWeekend)
	{
		//this.bevName=bevName; // beverage name
		 // bevSize= size;// beverage size
		super(bevName,bevType, size);
		IsWeekend=isWeekend; //whether the beverage is offered in the weekend false otherwise
	}
	
	/**Calculates the price of the alcohol
	 * */
	@Override
	public double calcPrice()
	{
		return PRICE_ALCOHOL;
	}
	@Override
	public String toString()
	{
	 String str;
	 str = "\nName of Beverage: " + bevName +
			 "\n Size of Beverage: " + bevSize +
			 "\n Whether Beverage is offered in weekend: " + IsWeekend+
			 "\n Price of Beverage: " + PRICE_ALCOHOL;
	 return str;
	}
	/**
	 *Checks if this Beverage equals to anotherBev
	 **/
	@Override
	 public boolean equals(Object anotherBev)
	{
		boolean status;
		 if(bevName.equals(anotherBev)&& bevType.equals(anotherBev)&& 
				 bevSize.equals(anotherBev)&& 
				 this.PRICE_ALCOHOL==this.anotherBev
				 && IsWeekend ==true)
			 status = true;
		 else
			 status = false;     
		return status;
	}
	/**
	 * Checks if is weekend
	 */
	public boolean isWeekend()
	{
		boolean status;
		  if(IsWeekend  ==true)
			  status = true;
			  else
				  status = false;
		  return status;
	}
	

}