
public class Size {

	public static final Size SMALL = null;
	public static final Size LARGE = null;
	public static final Size MEDIUM = null;

}
