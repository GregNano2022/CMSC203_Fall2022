
public class Customer extends Object
{
	private String name;
	private int age;
	private int Age;
	private String Name;

	public Customer(String name, int age)
	{
	name=this.name;
	age = this.age;
	}
	//copy constructor
	public Customer(Customer c)
	{
		name=c.name;
		age=c.age;
	}
	public int getAge()
	{
		return age;
	}
	public void setAge(int age)
	{
		 Age=age;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		Name=name;
	}
	@Override
	public String toString()
	{
		String str;
		str = "\n name:"+ name +
				"\n age:"+ age;
		return str;
		
	}
}
