/**
 Enumerated Type – Day
  */

enum DayType{MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY}
