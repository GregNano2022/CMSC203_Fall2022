/**
 Enumerated Type – Size
  */

enum SizeType{SMALL, MEDIUM, LARGE}
