/**
 Enumerated Type – Type
  */

enum TypeType{COFFE, SMOOTHIE, ALCOHOL}
