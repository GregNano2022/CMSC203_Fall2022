
/*
 * Class: CMSC203 
 * Instructor:Professor Gary Thai
 * Description: (Give a brief description for each Class)
 * Due: 12/07/2022
 * Platform/compiler:Windows/Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: _George K Ngatha_________
*/


/**
 * public abstract class Beverage extends Object
  *Represents a Beverage Object
 */
public abstract class Beverage extends Object
{
	protected String bevName;
	static Size bevSize;
	protected static double BasePrice = 2.0;
	protected double SIZE_PRICE=1;  
	protected static Type bevType;
	private static double PRICE_BEVERAGE;
	
	
	/**Beverage Constructor creates a beverage object using given values */
	public Beverage(String bevName, Type type, Size size)
	{
	this.bevName=bevName; // beverage name
     bevType=type ; // beverage type
	  bevSize=size; //beverage size
	}
	/**
	 * Gets the base price */
	public double getBasePrice()
	{
		return BasePrice ;
		
	}
	/**Gets beverage type */
	 public Type getType()
	 {
		 return bevType;
	 }
	 /**
	  *Gets the name of the beverage */
	 public String getBevName()
	 {
		return bevName;
		 
	 }
	 
	 /**Gets the size of the beverage */
	 public Size getSize()
	 {
		return bevSize;
		 
	 }
	 public double addSizePrice()
	 {
		 PRICE_BEVERAGE =  BasePrice +SIZE_PRICE;
		return PRICE_BEVERAGE;
	 }
	 /*
	  * Represents a Beverage object in String with the format of bevName,
	  * size
	  */
	 @Override
	 public String toString()
	 {
		 String str;
		  str = "\nName of Beverage: " + bevName +
				 "\n Size of Beverage: " + bevSize; 
		  return str;
	 }
	 /**Checks if this Beverage equals to anotherBev */
	 @Override
	 public boolean equals(Object anotherBev)
	 {
		 boolean status;
		 if(bevName.equals(anotherBev)&& bevType.equals(anotherBev)&& 
				 bevSize.equals(anotherBev))
			 status = true;
		 else
			 status = false;
		return status;
		 
	 }
	 /** Calculates the beverage price */
	 public abstract double calcPrice();

}
