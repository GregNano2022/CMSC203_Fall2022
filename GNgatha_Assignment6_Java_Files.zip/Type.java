
public class Type {

	public Type Type;

}
