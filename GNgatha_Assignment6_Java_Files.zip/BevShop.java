import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BevShop extends Object implements BevShopInterface
{
	
	public ArrayList<Order> orders;
	int MIN_AGE_FOR_ALCOHOL = 21;  //Minimum age for offering alcohol drink
	int MAX_ORDER_FOR_ALCOHOL= 3;   /*Maximum number of alcohol beverages
										that can be ordered within an order  */
	int MIN_TIME= 8;				//earliest time for the order
	int MAX_TIME= 23;				//latest  time for the order
	int MAX_FRUIT = 5;				//Maximum number of fruits that this shop offers for SMOOTHIE beverage
	private double totalMonthlySales;
	private int totalNumOfMonthlyOrders;
	private static Order CurrentOrder;
	private int numberOfDrinks;
	private Order finalOrder;
	private int currentOrderIndex;
	
	//default Constructor Initializes a BevShop Object
	public BevShop()
	{
		
	}
	//Checks if the time is valid (between 8 and 23 )
	public boolean isValidTime(int time)
	{
		boolean status;  
		if (time==8 || time==23)
			status = true;
		else
			status = false;
		return status;
	}
	public int getMaxNumOfFruits()
	{
		return MAX_FRUIT;
	}
	//returns the constant value for the Maximum age for offering Alcohol drink
	public int getMinAgeForAlcohol()
	{
		return MIN_AGE_FOR_ALCOHOL;
	}
	public boolean isMaxFruit(int numOfFruits)
	{
		boolean status;
		if(numOfFruits>MAX_FRUIT)
			status = true;
		else
			status = false;
		return status;
	}
	//returns constant maximum number of alcohol 
	//beverages/per order offered by the beverage shop
	public int getMaxOrderForAlcohol()
	{
		return MAX_ORDER_FOR_ALCOHOL;
	}
	//checks if the number of alcohol beverages for the 
	//current order has reached the maximum
	public boolean isEligibleForMore()
	{
		boolean status;
		
		if(numberOfDrinks==MAX_ORDER_FOR_ALCOHOL)
			status = true;
		else
			status = false;
		return status;
	}
	//returns the number of alcohol drinks for the current order
	public int getNumOfAlcoholDrink()
	{
		return numberOfDrinks;
	}
	public boolean isValidAge(int age)
	{
		boolean status;
		if(age>MIN_AGE_FOR_ALCOHOL)
			status = true;
		else
			status = false;
			return status;
	}
	public void startNewOrder(int time, Day day, String customerName, int customerAge)
	{
		
	}
	//process the Alcohol order for the current order by adding it to 
	//the current order
	public void processCoffeeOrder(String bevName, Size size, boolean extraShot, boolean extraSyrup)  
	{
		   
	}
	//Process Alcohol order for the current order by adding it to current order
	public void processAlcoholOrder(String bevName, Size size)
	{
	}
	public void processSmoothieOrder(String bevName, Size size, int numOfFruits, boolean addProtein)
	{
	}
	//locate an order based on the order number
	//returns the index of the order in the list of Orders if found 
	//or -1 if not found

	public int findOrder(int orderNo)
	{
		for (int i =0; i<orders.size(); i++)
			if (orders.indexOf(i)==orderNo)
				return orderNo;
			else
				return -1;
		return orderNo;
		
	}
	//locates an order in the list of orders and
	//returns the total value on the order.
	public double totalOrderPrice(int orderNo)
	{
		for (int i = 0; i<orders.size(); i++)
			if (orders.indexOf(i)==orderNo)
		//return totalOrderPrice;
				return orderNo;
	
		return orderNo;
		
	}
	//Calculates the total sale of all the orders for this beverage shop
	public double totalMonthlySale()
	{
		return totalMonthlySales;
	}
	//returns total numbers of orders within the month
	public int totalNumOfMonthlyOrders()
	{
		return totalNumOfMonthlyOrders;
	}
	
	//returns the current Order located in the index in the list of orders.
	public Order getCurrentOrder()
	{
		return orders.get(currentOrderIndex) ;
		
	}
	//returns Order in the list of orders at the index Notes:
	//this method returns the shallow copy of the order
	public Order getOrderAtIndex(int index)
	{
		  return orders.get(index);
		  
	}
	//sorts the orders within this bevShop using the Selection sort algorithm
	public void sortOrders()
	{
		 
		for ( int i = 0; i<orders.size()-1; i++)
		{
		int minIndex = i;
		int minValue=orders.get(i).getOrderNo();
		for (int j = i+1; j<orders.size(); j++)
		{
			if(orders.get(j).getOrderNo()< minValue)
			{
				minValue=orders.get(i).getOrderNo();
				minIndex= i;
			}
		}
		CurrentOrder=orders.get(minIndex);
			finalOrder=orders.get(i);
			CurrentOrder=finalOrder;
			
		}  
			
		}
			
	
	//returns the string representation of all the orders
	//and the total monthly sale
	@Override
	public String toString()
	{
		String str;
		str ="\nAll orders: " +totalNumOfMonthlyOrders +
				"\nTotal Monthly Sale: " +totalMonthlySales;
		return str;
	}
}
