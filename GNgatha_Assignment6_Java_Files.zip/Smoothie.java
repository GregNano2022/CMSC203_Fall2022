
public class Smoothie extends Beverage
{
       private static final double PRICE_PROTEIN = 1.50;
	private static final double PRICE_FRUIT = 0.5;
	private  final static double anotherBev = 0;
	private static final double addProtein = 0;
	//private String bevName;
      // Size bevSize;
	   private static int numOfFruits;
	   private  static  boolean AddProtein;
	private static double PRICE_SMOOTHIE;
	//bevName - Name of the beverage
		//size - Size of the beverage
		//numOfFruits - Number of fruits to be added to the smoothie
		//addProtein - Whether to add protein to the smoothie or not
public Smoothie(String bevName, Size size, int numOfFruits, boolean addProtein)
	{
		//bevName - Name of the beverage
		//size - Size of the beverage
		//numOfFruits - Number of fruits to be added to the smoothie
		//addProtein - Whether to add protein to the smoothie or not
		//this.bevName = bevName;
		//bevSize=size;
	    super(bevName, bevType, size);
		Smoothie.numOfFruits= numOfFruits;
		AddProtein = addProtein;
	}
public int getNumOfFruits()
{
	return numOfFruits;
}
public boolean getAddProtein()
{
	  boolean status;
	  if(AddProtein==true)
		  status = true;
		  else
			  status = false;
	  return status;
}
//returns the string representation of a Smoothie drink. 
//Contains the name , size, whether or not protein added ,
//number of fruits and price
@Override
public String toString()
{
	String str;
	str = "\name: " + bevName +
			"\nSize: " + bevSize +
			"\nContains Protein? " + AddProtein +
			"\nNumber of Fruits "+ numOfFruits +
			"\n Price:"+ PRICE_SMOOTHIE;
	return str;	
}
//calculates and returns the alcohol beverage price 
//return price of alcohol beverage
@Override
public double calcPrice()
{
	PRICE_SMOOTHIE = PRICE_PROTEIN+PRICE_FRUIT;
	return PRICE_SMOOTHIE;
}
//checks if this Beverage equals to anotherBev
@Override
public boolean equals(Object anotherBev)
{
	//returns true if the name, type, size and base price, number of Fruits
	//and add protein are the same, false otherwise
	boolean status;
	 if(bevName.equals(anotherBev)&& bevSize.equals(anotherBev)&& 
			 bevType.equals(anotherBev)&& 
			 Smoothie.PRICE_SMOOTHIE==Smoothie.anotherBev && 
			Smoothie.numOfFruits==Smoothie.anotherBev && 
			Smoothie.addProtein==Smoothie.anotherBev)
		
		 status = true;
	 else
		 status = false;
	return status;
	
}
}
